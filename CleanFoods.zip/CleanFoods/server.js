const mysql = require('mysql2');
const express = require('express');
const app = express();
const bodyParser = require('body-parser');

app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));

const connection = mysql.createConnection({
  host: 'localhost', 
  user: 'root',      
  password: 'Santos100501!', 
  database: 'cleanfoods' 
});


connection.connect((err) => {
  if (err) {
    console.error('Erro ao conectar ao banco de dados: ', err);
    return;
  }
  console.log('Conectado ao banco de dados!');
});

// Endpoint para adicionar feedback de usuário
app.post('/feedback/usuario', (req, res) => {
  const { usuario_id, feedback } = req.body;

  const query = 'INSERT INTO feedback_usuarios (usuario_id, feedback) VALUES (?, ?)';
  connection.query(query, [usuario_id, feedback], (err, results) => {
    if (err) {
      return res.status(500).json({ message: 'Erro ao salvar o feedback' });
    }
    res.status(200).json({ message: 'Feedback enviado com sucesso!' });
  });
});

// Endpoint para consultar feedbacks de usuários
app.get('/feedback/usuarios', (req, res) => {
  const query = 'SELECT usuarios.nome, feedback_usuarios.feedback FROM feedback_usuarios INNER JOIN usuarios ON feedback_usuarios.usuario_id = usuarios.id';

  connection.query(query, (err, results) => {
    if (err) {
      return res.status(500).json({ message: 'Erro ao recuperar feedbacks' });
    }
    res.status(200).json(results); // Retorna os feedbacks dos usuários
  });
});

// Endpoint para adicionar feedback de nutricionista
app.post('/feedback/nutricionista', (req, res) => {
  const { nutricionista_id, feedback } = req.body;

  const query = 'INSERT INTO feedback_nutricionistas (nutricionista_id, feedback) VALUES (?, ?)';
  connection.query(query, [nutricionista_id, feedback], (err, results) => {
    if (err) {
      return res.status(500).json({ message: 'Erro ao salvar o feedback' });
    }
    res.status(200).json({ message: 'Feedback enviado com sucesso!' });
  });
});

// Endpoint para consultar feedbacks de nutricionistas
app.get('/feedback/nutricionistas', (req, res) => {
  const query = 'SELECT nutricionistas.nome, feedback_nutricionistas.feedback FROM feedback_nutricionistas INNER JOIN nutricionistas ON feedback_nutricionistas.nutricionista_id = nutricionistas.id';

  connection.query(query, (err, results) => {
    if (err) {
      return res.status(500).json({ message: 'Erro ao recuperar feedbacks' });
    }
    res.status(200).json(results); // Retorna  os feedbacks dos nutricionistas
  });
});

// Endpoint de login para usuários
app.post('/login/usuario', (req, res) => {
  const { email, senha } = req.body;

  const query = 'SELECT * FROM usuarios WHERE email = ? AND senha = ?';
  connection.query(query, [email, senha], (err, results) => {
    if (err) {
      return res.status(500).json({ message: 'Erro ao realizar o login' });
    }

    if (results.length > 0) {
      res.status(200).json({ message: 'Login bem-sucedido', usuario: results[0] });
    } else {
      res.status(401).json({ message: 'Credenciais inválidas' });
    }
  });
});

// Endpoint de login para nutricionistas
app.post('/login/nutricionista', (req, res) => {
  const { email, senha } = req.body;

  const query = 'SELECT * FROM nutricionistas WHERE email = ? AND senha = ?';
  connection.query(query, [email, senha], (err, results) => {
    if (err) {
      return res.status(500).json({ message: 'Erro ao realizar o login' });
    }

    if (results.length > 0) {
      res.status(200).json({ message: 'Login bem-sucedido', nutricionista: results[0] });
    } else {
      res.status(401).json({ message: 'Credenciais inválidas' });
    }
  });
});

const PORT = 8080;
app.listen(PORT, () => {
  console.log(`Servidor rodando na porta ${PORT}`);
});
